# Oblig 5 for haan. 
# kjøh