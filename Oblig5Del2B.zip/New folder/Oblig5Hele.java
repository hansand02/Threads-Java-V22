public class Oblig5Hele {
    
}
